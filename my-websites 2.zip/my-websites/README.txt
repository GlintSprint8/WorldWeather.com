Upload steps (free):
1. Cloudflare Pages -> Create project -> Upload assets.
2. Upload the "weather" folder (or "dogs") and deploy.
3. Custom domains -> add your domain -> follow the DNS steps.
Test on the hosted address; live data does not load in sandboxed previews.
